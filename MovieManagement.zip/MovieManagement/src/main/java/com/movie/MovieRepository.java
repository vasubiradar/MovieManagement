package com.movie;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovieRepository extends JpaRepository<Movie, Long> {
    
    // Search by name
    List<Movie> findByNameContainingIgnoreCase(String name);

    // Filter by director
    List<Movie> findByDirectorIgnoreCase(String director);

    // Filter by cast
    List<Movie> findByCastContainingIgnoreCase(String cast);

    // Filter by genre
    List<Movie> findByGenreIgnoreCase(String genre);

    // Filter by year
    List<Movie> findByYear(int year);

    // Pagination and sorting
    Page<Movie> findAll(Pageable pageable);
}
