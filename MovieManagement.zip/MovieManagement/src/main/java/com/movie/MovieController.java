package com.movie;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/movies")
public class MovieController {

    @Autowired
    private MovieService movieService;

    // Add a new movie
    @PostMapping
    public ResponseEntity<Movie> addMovie(@RequestBody Movie movie) {
        return ResponseEntity.ok(movieService.saveMovie(movie));
    }

    // Get movie by ID
    @GetMapping("/{id}")
    public ResponseEntity<Movie> getMovieById(@PathVariable Long id) {
        Optional<Movie> movie = movieService.getMovieById(id);
        return movie.map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Get all movies with pagination & sorting
    @GetMapping
    public ResponseEntity<Page<Movie>> getAllMovies(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "name") String sortBy) {
        return ResponseEntity.ok(movieService.getAllMovies(page, size, sortBy));
    }

    // Search by name
    @GetMapping("/search")
    public ResponseEntity<List<Movie>> searchByName(@RequestParam String name) {
        return ResponseEntity.ok(movieService.searchByName(name));
    }

    // Filters
    @GetMapping("/filter/director")
    public ResponseEntity<List<Movie>> filterByDirector(@RequestParam String director) {
        return ResponseEntity.ok(movieService.filterByDirector(director));
    }

    @GetMapping("/filter/cast")
    public ResponseEntity<List<Movie>> filterByCast(@RequestParam String cast) {
        return ResponseEntity.ok(movieService.filterByCast(cast));
    }

    @GetMapping("/filter/genre")
    public ResponseEntity<List<Movie>> filterByGenre(@RequestParam String genre) {
        return ResponseEntity.ok(movieService.filterByGenre(genre));
    }

    @GetMapping("/filter/year")
    public ResponseEntity<List<Movie>> filterByYear(@RequestParam int year) {
        return ResponseEntity.ok(movieService.filterByYear(year));
    }

    // Update movie
    @PutMapping("/{id}")
    public ResponseEntity<Movie> updateMovie(@PathVariable Long id, @RequestBody Movie updatedMovie) {
        Optional<Movie> existingMovie = movieService.getMovieById(id);
        if (existingMovie.isPresent()) {
            updatedMovie.setId(id);
            return ResponseEntity.ok(movieService.saveMovie(updatedMovie));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Delete movie
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMovie(@PathVariable Long id) {
        movieService.deleteMovie(id);
        return ResponseEntity.noContent().build();
    }
    
}
