package com.example.MovieManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@ComponentScan(basePackages = {"com.movie", "com.user"})  // Ensure packages are scanned
@EntityScan(basePackages = {"com.movie", "com.user"})  // Ensure JPA Entities are detected
@EnableJpaRepositories(basePackages = {"com.movie", "com.user"})  // Ensure Repositories are detected
public class MovieManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(MovieManagementApplication.class, args);
        System.out.println("Started");
    }
}
